[InstallShield Silent]
Version=v7.00
File=Response File

[File Transfer]
OverwrittenReadOnly=NoToAll

[Application]
Name=Volari Reactor
Version=1.14.03
Company=XGI

[{D6B21BC2-91F9-45B4-BE99-C4DD0D07F59F}-DlgOrder]
Dlg0={D6B21BC2-91F9-45B4-BE99-C4DD0D07F59F}-SdWelcome-0
Count=2
Dlg1={D6B21BC2-91F9-45B4-BE99-C4DD0D07F59F}-SdFinishReboot-0

[{D6B21BC2-91F9-45B4-BE99-C4DD0D07F59F}-SdWelcome-0]
Result=1

[{D6B21BC2-91F9-45B4-BE99-C4DD0D07F59F}-SdFinishReboot-0]
Result=1
BootOption=0
